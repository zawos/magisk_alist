#!/system/bin/sh
kill $(pgrep alist) &&
echo "已关闭alist"