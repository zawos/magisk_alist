# 卸载模块时,删除运行过程中的备份文件
rm -rf /data/adb/Alist_online_backups